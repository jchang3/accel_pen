/*
 * dtw.h
 *
 *  Created on: 2014-01-31
 *      Author: jchang3
 *      http://bytefish.de/blog/dynamic_time_warping/
 */
#include <vector>


#ifndef DTW_H_
#define DTW_H_

namespace DTW {
    double dtw(const std::vector<double>& t1, const std::vector<double>& t2);
}

#endif
